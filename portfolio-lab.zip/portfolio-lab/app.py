"""
Portfolio Lab — Streamlit App
Correr con: streamlit run app.py
"""
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import sys
from pathlib import Path

# Para que encuentre el módulo engine
sys.path.insert(0, str(Path(__file__).parent))
from engine.analytics import build_portfolio, load_clients, load_config
from engine.report import generate_html_report, save_report

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Portfolio Lab — Balanz",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── CSS personalizado ─────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=DM+Sans:wght@300;400;500;600&display=swap');

html, body, [class*="css"] { font-family: 'DM Sans', sans-serif; }

/* Sidebar */
[data-testid="stSidebar"] {
    background: #1B2A4A;
}
[data-testid="stSidebar"] * { color: white !important; }
[data-testid="stSidebar"] .stSelectbox label { color: #90A8CC !important; font-size: 11px; text-transform: uppercase; letter-spacing: .8px; }

/* KPI metric cards */
[data-testid="stMetric"] {
    background: white;
    border: 1px solid #E8EDF5;
    border-radius: 10px;
    padding: 16px 20px !important;
    box-shadow: 0 1px 4px rgba(0,0,0,.05);
}
[data-testid="stMetricLabel"] { font-size: 11px !important; text-transform: uppercase; letter-spacing: .6px; color: #6B7C9B !important; }
[data-testid="stMetricValue"] { font-family: 'DM Serif Display', serif !important; font-size: 32px !important; color: #1B2A4A !important; }

/* Headers */
h1 { font-family: 'DM Serif Display', serif !important; color: #1B2A4A !important; }
h2, h3 { color: #2E4D8A !important; }

/* Section divider */
.section-header {
    font-family: 'DM Serif Display', serif;
    font-size: 20px;
    color: #1B2A4A;
    border-bottom: 2px solid #E8EDF5;
    padding-bottom: 8px;
    margin: 24px 0 16px;
}

/* Recommendation pills */
.rec-item {
    background: #F4F6FA;
    border-left: 3px solid #2E4D8A;
    padding: 12px 16px;
    border-radius: 0 6px 6px 0;
    margin-bottom: 8px;
    font-size: 13px;
    line-height: 1.5;
}
.rec-ok { border-left-color: #1A7A4A; background: #F0FBF4; }
.rec-warn { border-left-color: #C0392B; background: #FDF4F3; }

/* Badge */
.profile-badge {
    display: inline-block;
    padding: 4px 14px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: .5px;
}
.badge-conservador { background: #D6F5E3; color: #1A7A4A; }
.badge-moderado    { background: #FFF3CD; color: #856404; }
.badge-agresivo    { background: #FADBD8; color: #C0392B; }
</style>
""", unsafe_allow_html=True)

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### 📊 Portfolio Lab")
    st.markdown("---")

    clients_df = load_clients()
    client_options = {
        row["client_id"]: f"{row['client_name']} ({row['client_id']})"
        for _, row in clients_df.iterrows()
    }

    selected_id = st.selectbox(
        "Cliente",
        options=list(client_options.keys()),
        format_func=lambda x: client_options[x],
    )

    st.markdown("---")
    st.markdown("##### Datos")
    if st.button("🔄 Recargar datos", use_container_width=True):
        st.cache_data.clear()
        st.rerun()

    st.markdown("##### Cargar CSVs")
    uploaded = st.file_uploader("holdings.csv", type="csv", key="holdings_up")
    if uploaded:
        path = Path("data/holdings.csv")
        path.parent.mkdir(exist_ok=True)
        path.write_bytes(uploaded.read())
        st.success("✅ holdings.csv actualizado")
        st.rerun()

    uploaded_cl = st.file_uploader("clients.csv", type="csv", key="clients_up")
    if uploaded_cl:
        Path("data/clients.csv").write_bytes(uploaded_cl.read())
        st.success("✅ clients.csv actualizado")
        st.rerun()

    st.markdown("---")
    st.markdown('<div style="font-size:10px;opacity:.5">Portfolio Lab v1.0<br>Balanz — Asesor Independiente</div>', unsafe_allow_html=True)

# ── Main content ──────────────────────────────────────────────────────────────

@st.cache_data(ttl=120, show_spinner=False)
def get_portfolio(client_id: str):
    return build_portfolio(client_id)

with st.spinner("Calculando cartera..."):
    ps = get_portfolio(selected_id)

if ps is None:
    st.error("No se encontraron datos para este cliente. Verificá los archivos CSV.")
    st.stop()

# ── Header ────────────────────────────────────────────────────────────────────
col_h1, col_h2 = st.columns([3, 1])
with col_h1:
    badge_class = f"badge-{ps.risk_profile}"
    st.markdown(
        f"# {ps.client_name} "
        f'<span class="profile-badge {badge_class}">{ps.risk_profile}</span>',
        unsafe_allow_html=True,
    )
    st.markdown(f"**Moneda base:** {ps.base_currency} &nbsp;·&nbsp; **ID:** {ps.client_id}")
with col_h2:
    if st.button("📄 Exportar Reporte HTML", use_container_width=True, type="primary"):
        html_content = generate_html_report(ps)
        st.download_button(
            label="⬇️ Descargar HTML",
            data=html_content.encode("utf-8"),
            file_name=f"reporte_{ps.client_id}.html",
            mime="text/html",
            use_container_width=True,
        )

st.markdown("---")

# ── KPIs ──────────────────────────────────────────────────────────────────────
k1, k2, k3, k4, k5 = st.columns(5)
k1.metric("💰 Total Cartera", f"USD {ps.total_value_usd:,.0f}")
k2.metric("📈 Retorno Esperado", f"{ps.expected_return:.1f}%", help="Yield ponderado por peso")
k3.metric("⏱ Duration (RF)", f"{ps.portfolio_duration:.1f} años", help="Duration Macaulay aprox. solo renta fija")
k4.metric("⚡ Riesgo Agregado", f"{ps.portfolio_risk_score:.1f}/10", help="Score ponderado por peso")
k5.metric("🔵 HHI Concentración", f"{ps.hhi:.3f}", help="0=diversificado, 1=concentrado en 1 activo")

st.markdown("")

# ── Exposición + Recomendaciones ──────────────────────────────────────────────
col_charts, col_recs = st.columns([3, 2])

with col_charts:
    st.markdown('<div class="section-header">Exposición de Cartera</div>', unsafe_allow_html=True)

    tab1, tab2, tab3 = st.tabs(["Clase de Activo", "Moneda", "País"])

    COLORS = ["#1B2A4A","#2E4D8A","#4A7FC1","#00B4D8","#1A7A4A","#FFD166","#EF476F","#B8860B"]

    with tab1:
        df_ac = pd.DataFrame(ps.exposure_by_asset_class.items(), columns=["Clase","Peso %"])
        fig = px.pie(df_ac, values="Peso %", names="Clase", color_discrete_sequence=COLORS,
                     hole=0.45)
        fig.update_traces(textposition="outside", textinfo="label+percent")
        fig.update_layout(margin=dict(t=20,b=20,l=20,r=20), showlegend=True,
                         legend=dict(orientation="h", y=-0.1), height=300,
                         font_family="DM Sans")
        st.plotly_chart(fig, use_container_width=True)

    with tab2:
        df_cur = pd.DataFrame(ps.exposure_by_currency.items(), columns=["Moneda","Peso %"])
        fig = px.pie(df_cur, values="Peso %", names="Moneda", color_discrete_sequence=COLORS,
                     hole=0.45)
        fig.update_traces(textposition="outside", textinfo="label+percent")
        fig.update_layout(margin=dict(t=20,b=20,l=20,r=20), showlegend=True,
                         legend=dict(orientation="h", y=-0.1), height=300,
                         font_family="DM Sans")
        st.plotly_chart(fig, use_container_width=True)

    with tab3:
        df_cty = pd.DataFrame(ps.exposure_by_country.items(), columns=["País","Peso %"])
        fig = px.bar(df_cty.sort_values("Peso %", ascending=True),
                     x="Peso %", y="País", orientation="h",
                     color_discrete_sequence=["#2E4D8A"])
        fig.update_layout(margin=dict(t=10,b=10,l=10,r=10), height=250,
                         font_family="DM Sans", plot_bgcolor="white",
                         xaxis=dict(gridcolor="#E8EDF5"))
        st.plotly_chart(fig, use_container_width=True)

with col_recs:
    st.markdown('<div class="section-header">Recomendaciones</div>', unsafe_allow_html=True)
    for rec in ps.recommendations:
        if rec.startswith("✅"):
            css = "rec-item rec-ok"
        elif rec.startswith("⚠️"):
            css = "rec-item rec-warn"
        else:
            css = "rec-item"
        st.markdown(f'<div class="{css}">{rec}</div>', unsafe_allow_html=True)

# ── Holdings table ────────────────────────────────────────────────────────────
st.markdown('<div class="section-header">Posiciones Detalle</div>', unsafe_allow_html=True)

h = ps.holdings.copy()
h.columns = [c.replace("_"," ").title() for c in h.columns]

# Rename for display
rename_map = {
    "Market Value Usd":  "Val. USD",
    "Weight":            "Peso %",
    "Ytm":               "TIR/Yield %",
    "Duration":          "Duration",
    "Risk Score":        "Riesgo /10",
    "Instrument Name":   "Nombre",
    "Instrument Type":   "Tipo",
    "Asset Class":       "Clase",
}
h = h.rename(columns=rename_map)

# Format
if "Val. USD" in h.columns:
    h["Val. USD"] = h["Val. USD"].apply(lambda x: f"${x:,.0f}")
if "Peso %" in h.columns:
    h["Peso %"] = h["Peso %"].apply(lambda x: f"{x:.1f}%")
if "TIR/Yield %" in h.columns:
    h["TIR/Yield %"] = h["TIR/Yield %"].apply(lambda x: f"{x:.1f}%" if x > 0 else "—")
if "Duration" in h.columns:
    h["Duration"] = h["Duration"].apply(lambda x: f"{x:.1f}" if x > 0 else "—")

st.dataframe(h, use_container_width=True, hide_index=True,
             column_config={
                 "Peso %":      st.column_config.TextColumn(width="small"),
                 "Val. USD":    st.column_config.TextColumn(width="medium"),
                 "Riesgo /10":  st.column_config.NumberColumn(format="%.1f", width="small"),
             })

# ── Risk waterfall ────────────────────────────────────────────────────────────
st.markdown('<div class="section-header">Contribución al Riesgo por Posición</div>', unsafe_allow_html=True)

h_raw = ps.holdings.copy()
if "risk_score" in h_raw.columns and "weight" in h_raw.columns:
    h_raw["contrib_risk"] = h_raw["weight"] / 100 * h_raw["risk_score"]
    h_raw = h_raw.sort_values("contrib_risk", ascending=False).head(10)
    fig_risk = px.bar(
        h_raw, x="ticker", y="contrib_risk",
        labels={"ticker": "", "contrib_risk": "Contribución al Riesgo"},
        color="contrib_risk",
        color_continuous_scale=["#1A7A4A","#FFD166","#C0392B"],
    )
    fig_risk.update_layout(
        height=240, margin=dict(t=10,b=10,l=10,r=10),
        plot_bgcolor="white", coloraxis_showscale=False,
        font_family="DM Sans",
        xaxis=dict(gridcolor="#E8EDF5"),
        yaxis=dict(gridcolor="#E8EDF5"),
    )
    st.plotly_chart(fig_risk, use_container_width=True)

# ── Footer ────────────────────────────────────────────────────────────────────
cfg = load_config()
st.markdown("---")
st.markdown(
    f'<div style="font-size:10px;color:#9AAABE;line-height:1.6">'
    f'<b>Disclaimer:</b> {cfg["report"]["disclaimer"]}</div>',
    unsafe_allow_html=True
)
